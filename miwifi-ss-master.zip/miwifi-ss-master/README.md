# WHAT
小米路由器 shadowsocks 插件

[小米路由器3最新开启SSH与安装Shadowsocks方法（7月19日）](http://bbs.xiaomi.cn/t-13066771)

# USAGE
cd /userdisk && rm -rf miwifi.sh && wget http://7xo6sw.com1.z0.glb.clouddn.com/miwifi.sh && chmod +x miwifi.sh && sh ./miwifi.sh

